# Emotion-detection
Overview : Real time emotion detection using keras

Dependencies :
1.Keras
2.Tensorflow
3.numpy
4.Pandas
5.openCV

Kaggle dataset Link : https://www.kaggle.com/c/challenges-in-representation-learning-facial-expression-recognition-challenge/data

Download haarcascades file : https://github.com/opencv/opencv/blob/master/data/haarcascades/haarcascade_frontalface_default.xml

Acknowledgements: https://www.youtube.com/watch?time_continue=2702&v=PGH8uSzTTzc
